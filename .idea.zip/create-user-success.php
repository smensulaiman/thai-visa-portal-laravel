<?php
require "config.php";
require "header.php";
?>
<div class="card card-nav-tabs text-center">
  <div class="card-body">
    <h4 class="card-title">User created successfully!</h4>
    <a href="index.php" class="btn btn-primary">Go back</a>
  </div>
</div>
<?php require "footer.php"; ?>
